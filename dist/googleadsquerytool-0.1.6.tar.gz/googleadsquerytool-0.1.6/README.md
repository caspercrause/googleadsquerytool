# GoogleAdsQueryTool

This is a package you can use to query reporting data from the Google Ads API.

## Installation
```
pip install googleadsquerytool
```
